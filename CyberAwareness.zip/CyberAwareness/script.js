// ======================================
// CYBER ACADEMY - MAIN JAVASCRIPT
// ======================================


// MOBILE NAVIGATION

const menuToggle = document.getElementById("menuToggle");
const navMenu = document.getElementById("navMenu");

menuToggle.addEventListener("click", () => {
    navMenu.classList.toggle("active");

    menuToggle.textContent =
        navMenu.classList.contains("active") ? "✕" : "☰";
});

document.querySelectorAll("#navMenu a").forEach(link => {
    link.addEventListener("click", () => {
        navMenu.classList.remove("active");
        menuToggle.textContent = "☰";
    });
});


// CYBERSECURITY TOOL MODAL

function showTool(name, description) {

    document.getElementById("modalTitle").textContent = name;

    document.getElementById("modalDescription").textContent =
        description;

    document.getElementById("toolModal").classList.add("active");

    document.body.style.overflow = "hidden";
}


function closeModal() {

    document.getElementById("toolModal").classList.remove("active");

    document.body.style.overflow = "auto";
}


// CLOSE MODAL WHEN CLICKING OUTSIDE

document.getElementById("toolModal").addEventListener("click", event => {

    if (event.target.id === "toolModal") {
        closeModal();
    }

});


// CLOSE MODAL WITH ESCAPE KEY

document.addEventListener("keydown", event => {

    if (event.key === "Escape") {
        closeModal();
    }

});


// TOOL SEARCH FUNCTIONALITY

const toolSearch = document.getElementById("toolSearch");
const toolFilter = document.getElementById("toolFilter");

const toolCards = document.querySelectorAll(".tool-card");


function filterTools() {

    const searchValue = toolSearch.value.toLowerCase();

    const categoryValue = toolFilter.value;

    toolCards.forEach(card => {

        const cardText = card.textContent.toLowerCase();

        const cardCategory = card.dataset.category;

        const matchesSearch = cardText.includes(searchValue);

        const matchesCategory =
            categoryValue === "all" ||
            categoryValue === cardCategory;

        if (matchesSearch && matchesCategory) {

            card.classList.remove("hidden");

        } else {

            card.classList.add("hidden");

        }

    });

}


toolSearch.addEventListener("input", filterTools);

toolFilter.addEventListener("change", filterTools);


// CONTACT FORM

const contactForm = document.getElementById("contactForm");

contactForm.addEventListener("submit", event => {

    event.preventDefault();

    const message = document.getElementById("formMessage");

    message.textContent =
        "Thank you! Your message has been prepared successfully. Connect a backend or email service to deliver it.";

    contactForm.reset();

});


// ACTIVE NAVIGATION

const sections = document.querySelectorAll("section[id]");

const navigationLinks = document.querySelectorAll(".navbar nav a");

window.addEventListener("scroll", () => {

    let currentSection = "";

    sections.forEach(section => {

        const sectionTop = section.offsetTop - 120;

        if (window.scrollY >= sectionTop) {

            currentSection = section.getAttribute("id");

        }

    });

    navigationLinks.forEach(link => {

        link.style.color = "";

        if (link.getAttribute("href") === "#" + currentSection) {

            link.style.color = "#00D9FF";

        }

    });

});


// SMOOTH SCROLL

document.querySelectorAll('a[href^="#"]').forEach(anchor => {

    anchor.addEventListener("click", function(event) {

        const target = document.querySelector(
            this.getAttribute("href")
        );

        if (target) {

            event.preventDefault();

            target.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });

        }

    });

});


// WELCOME MESSAGE

console.log("%c CYBER ACADEMY ", "background:#00D9FF;color:#080D18;font-size:20px;font-weight:bold;padding:10px;");

console.log(
    "%c Welcome to the Cybersecurity Learning Platform!",
    "color:#00D9FF;font-size:14px;"
);